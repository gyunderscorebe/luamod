
-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `access` tinyint(4) NOT NULL DEFAULT '0',
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `count` bigint(20) NOT NULL DEFAULT '0',
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `user`
--

TRUNCATE TABLE `user`;
--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`name`, `pwd`, `access`, `date_create`, `date_login`, `count`) VALUES
('|VAH|-SDBS', '2006', 50, '2016-12-06 01:50:52', '2016-12-06 04:49:44', 0),
('|VAH|-Vahe', 'Vahe42_', 50, '2016-12-06 01:51:11', '2016-12-06 02:01:15', 0);
